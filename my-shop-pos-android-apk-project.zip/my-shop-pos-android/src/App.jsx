import React, { useEffect, useMemo, useState } from 'react';

const money = n => `৳${Number(n || 0).toLocaleString('bn-BD', { maximumFractionDigits: 2 })}`;
const today = () => new Date().toISOString().slice(0, 10);
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const starterProducts = [
  { id: 'p1', name: 'চাল', code: '1001', buy: 58, sell: 65, stock: 40, unit: 'কেজি' },
  { id: 'p2', name: 'ডাল', code: '1002', buy: 95, sell: 110, stock: 25, unit: 'কেজি' },
  { id: 'p3', name: 'সয়াবিন তেল', code: '1003', buy: 165, sell: 180, stock: 18, unit: 'লিটার' },
  { id: 'p4', name: 'চিনি', code: '1004', buy: 120, sell: 135, stock: 30, unit: 'কেজি' },
  { id: 'p5', name: 'সাবান', code: '1005', buy: 32, sell: 40, stock: 50, unit: 'টি' },
  { id: 'p6', name: 'বিস্কুট', code: '1006', buy: 8, sell: 10, stock: 60, unit: 'প্যাকেট' },
];
const initial = {
  products: starterProducts,
  sales: [], purchases: [], expenses: [], customers: [], payments: [],
  shopName: 'My Shop POS',
};

function readData() {
  try { const saved = localStorage.getItem('my-shop-pos-v1'); return saved ? { ...initial, ...JSON.parse(saved) } : initial; }
  catch { return initial; }
}

export default function App() {
  const [data, setData] = useState(readData);
  const [page, setPage] = useState('home');
  const [query, setQuery] = useState('');
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState({ name: '', phone: '', address: '' });
  const [paid, setPaid] = useState('');
  const [productForm, setProductForm] = useState({ id: '', name: '', code: '', buy: '', sell: '', stock: '', unit: 'টি' });
  const [showProductForm, setShowProductForm] = useState(false);
  const [purchaseForm, setPurchaseForm] = useState({ productId: '', qty: '', buy: '', supplier: '' });
  const [expenseForm, setExpenseForm] = useState({ title: '', amount: '', note: '' });
  const [dateFilter, setDateFilter] = useState(today());
  const [notice, setNotice] = useState('');

  useEffect(() => { localStorage.setItem('my-shop-pos-v1', JSON.stringify(data)); }, [data]);
  const notify = msg => { setNotice(msg); setTimeout(() => setNotice(''), 2600); };
  const update = patch => setData(prev => ({ ...prev, ...patch }));
  const products = data.products || [];
  const sales = data.sales || [];
  const dues = useMemo(() => {
    const map = {};
    sales.forEach(s => { if (s.due > 0) { const key = s.customerPhone || s.customerName || 'unknown'; map[key] ||= { key, name: s.customerName || 'নাম নেই', phone: s.customerPhone || '', address: s.customerAddress || '', due: 0, sales: [] }; map[key].due += s.due; map[key].sales.push(s.id); } });
    (data.payments || []).forEach(p => { const key = p.customerPhone || p.customerName || 'unknown'; if (map[key]) map[key].due -= p.amount; });
    return Object.values(map).filter(x => x.due > 0);
  }, [sales, data.payments]);
  const totalDue = dues.reduce((a, b) => a + b.due, 0);
  const todaySales = sales.filter(s => s.date === today());
  const todayTotal = todaySales.reduce((a, s) => a + s.total, 0);
  const todayProfit = todaySales.reduce((a, s) => a + s.profit, 0);
  const allProfit = sales.reduce((a, s) => a + s.profit, 0) - (data.expenses || []).reduce((a, e) => a + e.amount, 0);
  const filteredProducts = products.filter(p => `${p.name} ${p.code}`.toLowerCase().includes(query.toLowerCase()));
  const cartTotal = cart.reduce((a, item) => a + item.price * item.qty, 0);
  const cartCost = cart.reduce((a, item) => a + item.buy * item.qty, 0);

  function addToCart(product) {
    setCart(prev => {
      const found = prev.find(x => x.id === product.id);
      if ((found?.qty || 0) + 1 > product.stock) { notify('স্টকে পর্যাপ্ত পণ্য নেই'); return prev; }
      return found ? prev.map(x => x.id === product.id ? { ...x, qty: x.qty + 1 } : x) : [...prev, { id: product.id, name: product.name, price: product.sell, buy: product.buy, qty: 1 }];
    });
  }
  function changeQty(id, qty) {
    const p = products.find(x => x.id === id);
    if (!p || qty < 1) { setCart(prev => prev.filter(x => x.id !== id)); return; }
    if (qty > p.stock) { notify('স্টকে এত পণ্য নেই'); return; }
    setCart(prev => prev.map(x => x.id === id ? { ...x, qty } : x));
  }
  function finishSale() {
    if (!cart.length) return notify('আগে পণ্য নির্বাচন করুন');
    const pay = Number(paid === '' ? cartTotal : paid);
    if (!Number.isFinite(pay) || pay < 0 || pay > cartTotal) return notify('জমার টাকা সঠিকভাবে লিখুন');
    if (pay < cartTotal && !customer.name.trim()) return notify('বাকি বিক্রির জন্য ক্রেতার নাম লিখুন');
    const sale = { id: uid(), date: today(), createdAt: new Date().toISOString(), customerName: customer.name.trim() || 'সাধারণ ক্রেতা', customerPhone: customer.phone.trim(), customerAddress: customer.address.trim(), items: cart, total: cartTotal, paid: pay, due: cartTotal - pay, cost: cartCost, profit: cartTotal - cartCost };
    update({ sales: [sale, ...sales], products: products.map(p => { const item = cart.find(x => x.id === p.id); return item ? { ...p, stock: p.stock - item.qty } : p; }) });
    setCart([]); setCustomer({ name: '', phone: '', address: '' }); setPaid(''); notify('বিক্রি সফলভাবে সংরক্ষণ হয়েছে'); setPage('sales');
  }
  function saveProduct(e) {
    e.preventDefault();
    if (!productForm.name.trim()) return notify('পণ্যের নাম লিখুন');
    const p = { ...productForm, id: productForm.id || uid(), buy: Number(productForm.buy), sell: Number(productForm.sell), stock: Number(productForm.stock), code: productForm.code || String(Date.now()).slice(-6), unit: productForm.unit || 'টি' };
    if ([p.buy, p.sell, p.stock].some(n => !Number.isFinite(n) || n < 0)) return notify('দাম ও স্টকের ঘর ঠিকভাবে পূরণ করুন');
    update({ products: productForm.id ? products.map(x => x.id === p.id ? p : x) : [p, ...products] });
    setProductForm({ id: '', name: '', code: '', buy: '', sell: '', stock: '', unit: 'টি' }); setShowProductForm(false); notify('পণ্য সংরক্ষণ হয়েছে');
  }
  function deleteProduct(id) { if (confirm('এই পণ্যটি মুছে ফেলবেন?')) update({ products: products.filter(p => p.id !== id) }); }
  function savePurchase(e) {
    e.preventDefault(); const p = products.find(x => x.id === purchaseForm.productId); const qty = Number(purchaseForm.qty); const buy = Number(purchaseForm.buy);
    if (!p || qty <= 0 || buy < 0) return notify('ক্রয়ের তথ্য ঠিকভাবে পূরণ করুন');
    update({ products: products.map(x => x.id === p.id ? { ...x, stock: x.stock + qty, buy } : x), purchases: [{ id: uid(), date: today(), product: p.name, qty, buy, total: qty * buy, supplier: purchaseForm.supplier }, ...(data.purchases || [])] });
    setPurchaseForm({ productId: '', qty: '', buy: '', supplier: '' }); notify('মাল কেনার হিসাব যোগ হয়েছে');
  }
  function saveExpense(e) {
    e.preventDefault(); const amount = Number(expenseForm.amount); if (!expenseForm.title.trim() || amount <= 0) return notify('খরচের নাম ও টাকা লিখুন');
    update({ expenses: [{ id: uid(), date: today(), title: expenseForm.title, amount, note: expenseForm.note }, ...(data.expenses || [])] }); setExpenseForm({ title: '', amount: '', note: '' }); notify('খরচ সংরক্ষণ হয়েছে');
  }
  function addPayment(due) {
    const raw = prompt(`${due.name}-এর কাছ থেকে কত টাকা জমা নিলেন?`); if (raw === null) return; const amount = Number(raw);
    if (!Number.isFinite(amount) || amount <= 0 || amount > due.due) return notify('টাকার পরিমাণ সঠিক নয়');
    update({ payments: [{ id: uid(), date: today(), customerName: due.name, customerPhone: due.phone, amount }, ...(data.payments || [])] }); notify('জমা টাকা হিসাব করা হয়েছে');
  }
  const nav = [{ id: 'home', label: 'হোম', icon: '⌂' }, { id: 'purchase', label: 'ক্রয়', icon: '📦' }, { id: 'pos', label: 'POS', icon: '▣' }, { id: 'due', label: 'বাকি', icon: '📒' }, { id: 'more', label: 'আরও', icon: '☰' }];
  const Card = ({ children, className = '' }) => <div className={`rounded-2xl bg-white border border-slate-100 shadow-sm ${className}`}>{children}</div>;
  const Stat = ({ label, value, color = 'text-slate-900', icon = '৳' }) => <Card className="p-4"><div className="flex justify-between text-slate-500 text-sm"><span>{label}</span><span>{icon}</span></div><div className={`text-xl font-extrabold mt-2 ${color}`}>{value}</div></Card>;
  const Header = ({ title, sub }) => <div className="bg-emerald-600 text-white px-5 pt-5 pb-6 rounded-b-[28px]"><div className="text-xl font-extrabold">{title}</div>{sub && <div className="text-emerald-100 text-sm mt-1">{sub}</div>}</div>;

  return <div className="min-h-screen bg-slate-50 text-slate-800 pb-24">
    <div className="max-w-md mx-auto min-h-screen bg-slate-50 shadow-xl relative">
      <div className="bg-emerald-700 text-white px-5 py-3 flex items-center justify-between"><div><div className="font-bold">🟢 {data.shopName}</div><div className="text-[11px] text-emerald-100">সহজ দোকান হিসাব</div></div><button onClick={() => { const name = prompt('দোকানের নাম লিখুন', data.shopName); if (name?.trim()) update({ shopName: name.trim() }); }} className="text-xs bg-white/15 px-3 py-2 rounded-xl">নাম বদল</button></div>
      {page === 'home' && <><Header title="ড্যাশবোর্ড" sub="আপনার দোকানের আজকের হিসাব"/><div className="px-4 -mt-3 grid grid-cols-2 gap-3"><Stat label="আজকের বিক্রি" value={money(todayTotal)} color="text-emerald-700"/><Stat label="আজকের লাভ" value={money(todayProfit)} color="text-blue-700"/><Stat label="মোট বাকি" value={money(totalDue)} color="text-rose-600"/><Stat label="মোট লাভ (খরচ বাদে)" value={money(allProfit)} color="text-violet-700"/></div><div className="px-4 mt-5"><div className="font-bold mb-3">দ্রুত কাজ</div><div className="grid grid-cols-2 gap-3">{[['pos','＋ নতুন বিক্রি'],['products','🛍 পণ্য তালিকা'],['purchase','📦 মাল ক্রয়'],['due','📒 বাকি খাতা'],['reports','📊 রিপোর্ট'],['expenses','🧾 খরচ যোগ']].map(([id,label])=><button key={id} onClick={()=>setPage(id)} className="bg-white border border-slate-100 shadow-sm rounded-2xl p-4 text-left font-semibold text-emerald-800">{label}<div className="text-xs text-slate-400 mt-1">খুলতে চাপ দিন →</div></button>)}</div></div><div className="px-4 mt-5"><div className="font-bold mb-3">সাম্প্রতিক বিক্রি</div><Card>{sales.slice(0,4).length ? sales.slice(0,4).map(s=><div key={s.id} className="p-3 border-b last:border-0 border-slate-100 flex justify-between"><div><div className="font-semibold">{s.customerName}</div><div className="text-xs text-slate-400">{s.date} · {s.items.length} পণ্য</div></div><div className="text-right"><div className="font-bold">{money(s.total)}</div><div className="text-xs text-emerald-600">লাভ {money(s.profit)}</div></div></div>):<div className="p-5 text-center text-slate-400">এখনো কোনো বিক্রি নেই</div>}</Card></div></>}

      {page === 'pos' && <><Header title="নতুন বিক্রি (POS)" sub="পণ্য বেছে কার্টে যোগ করুন"/><div className="p-4"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="পণ্যের নাম বা কোড দিয়ে খুঁজুন..." className="w-full rounded-xl border bg-white px-4 py-3 outline-emerald-500"/><div className="grid grid-cols-2 gap-3 mt-3">{filteredProducts.map(p=><button key={p.id} onClick={()=>addToCart(p)} className="bg-white rounded-2xl border p-3 text-left shadow-sm"><div className="h-12 w-12 rounded-xl bg-emerald-50 flex items-center justify-center text-2xl">🛍</div><div className="font-bold mt-2">{p.name}</div><div className="text-emerald-700 font-bold">{money(p.sell)}</div><div className="text-xs text-slate-400">স্টক: {p.stock} {p.unit}</div><div className="text-xs text-emerald-600 mt-1">＋ কার্টে যোগ</div></button>)}</div><div className="font-bold mt-5 mb-2">কার্ট ({cart.length})</div><Card className="p-3">{cart.length ? cart.map(item=><div key={item.id} className="flex items-center gap-2 py-2 border-b last:border-0"><div className="flex-1"><div className="font-semibold">{item.name}</div><div className="text-xs text-slate-400">{money(item.price)} × {item.qty}</div></div><div className="flex items-center gap-2"><button onClick={()=>changeQty(item.id,item.qty-1)} className="w-8 h-8 rounded-lg bg-slate-100">−</button><span className="font-bold">{item.qty}</span><button onClick={()=>changeQty(item.id,item.qty+1)} className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700">＋</button></div><button onClick={()=>changeQty(item.id,0)} className="text-rose-500 px-1">✕</button></div>):<div className="text-center text-slate-400 py-4">এখনো পণ্য যোগ করা হয়নি</div>}</Card><div className="font-bold mt-5 mb-2">ক্রেতার তথ্য</div><Card className="p-3 space-y-2"><input value={customer.name} onChange={e=>setCustomer({...customer,name:e.target.value})} placeholder="ক্রেতার নাম (বাকি হলে আবশ্যক)" className="field"/><input value={customer.phone} onChange={e=>setCustomer({...customer,phone:e.target.value})} placeholder="মোবাইল নম্বর" className="field"/><input value={customer.address} onChange={e=>setCustomer({...customer,address:e.target.value})} placeholder="ঠিকানা" className="field"/></Card><Card className="p-4 mt-3"><div className="flex justify-between"><span>মোট বিক্রি</span><b>{money(cartTotal)}</b></div><div className="flex justify-between text-emerald-700 mt-1"><span>সম্ভাব্য লাভ</span><b>{money(cartTotal-cartCost)}</b></div><label className="block text-sm mt-3 mb-1">জমা টাকা (সম্পূর্ণ বাকি হলে ০ লিখুন)</label><input type="number" value={paid} onChange={e=>setPaid(e.target.value)} placeholder={String(cartTotal)} className="field"/><div className="flex justify-between text-rose-600 mt-2"><span>বাকি থাকবে</span><b>{money(Math.max(0,cartTotal-(paid===''?cartTotal:Number(paid)||0)))}</b></div><button onClick={finishSale} className="w-full mt-4 rounded-xl bg-emerald-600 text-white font-bold py-3">বিক্রি সংরক্ষণ করুন</button></Card></div></>}

      {page === 'products' && <><Header title="পণ্য ও স্টক" sub="পাইকারি ক্রয়মূল্য ও খুচরা বিক্রয়মূল্য"/><div className="p-4"><button onClick={()=>{setProductForm({id:'',name:'',code:'',buy:'',sell:'',stock:'',unit:'টি'});setShowProductForm(!showProductForm)}} className="w-full bg-emerald-600 text-white rounded-xl py-3 font-bold">＋ নতুন পণ্য যোগ করুন</button>{showProductForm&&<form onSubmit={saveProduct} className="bg-white rounded-2xl p-4 mt-3 space-y-2"><div className="font-bold">{productForm.id?'পণ্য এডিট':'নতুন পণ্যের তথ্য'}</div><input className="field" placeholder="পণ্যের নাম" value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value})}/><input className="field" placeholder="পণ্য কোড (ঐচ্ছিক)" value={productForm.code} onChange={e=>setProductForm({...productForm,code:e.target.value})}/><div className="grid grid-cols-2 gap-2"><input className="field" type="number" placeholder="পাইকারি দাম" value={productForm.buy} onChange={e=>setProductForm({...productForm,buy:e.target.value})}/><input className="field" type="number" placeholder="খুচরা দাম" value={productForm.sell} onChange={e=>setProductForm({...productForm,sell:e.target.value})}/></div><div className="grid grid-cols-2 gap-2"><input className="field" type="number" placeholder="স্টকের পরিমাণ" value={productForm.stock} onChange={e=>setProductForm({...productForm,stock:e.target.value})}/><select className="field" value={productForm.unit} onChange={e=>setProductForm({...productForm,unit:e.target.value})}><option>টি</option><option>কেজি</option><option>লিটার</option><option>প্যাকেট</option><option>বস্তা</option><option>ডজন</option></select></div><div className="flex gap-2"><button className="flex-1 bg-emerald-600 text-white rounded-xl py-2">সংরক্ষণ</button><button type="button" onClick={()=>setShowProductForm(false)} className="px-4 bg-slate-100 rounded-xl">বন্ধ</button></div></form>}<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="পণ্য খুঁজুন" className="field mt-3"/><div className="space-y-2 mt-3">{filteredProducts.map(p=><Card key={p.id} className="p-3"><div className="flex justify-between"><div><div className="font-bold">{p.name}</div><div className="text-xs text-slate-400">কোড: {p.code} · স্টক: {p.stock} {p.unit}</div><div className="text-sm mt-1">ক্রয় {money(p.buy)} · বিক্রয় {money(p.sell)}</div></div><div className="flex flex-col gap-2"><button onClick={()=>{setProductForm({...p});setShowProductForm(true);window.scrollTo({top:0,behavior:'smooth'})}} className="text-emerald-700 text-sm">এডিট</button><button onClick={()=>deleteProduct(p.id)} className="text-rose-500 text-sm">মুছুন</button></div></div></Card>)}</div></div></>}

      {page === 'purchase' && <><Header title="মাল ক্রয় / স্টক ইন" sub="নতুন মাল কিনলে এখানে যোগ করুন"/><div className="p-4"><form onSubmit={savePurchase} className="bg-white p-4 rounded-2xl space-y-3"><label className="font-bold">পণ্য নির্বাচন</label><select className="field" value={purchaseForm.productId} onChange={e=>{const p=products.find(x=>x.id===e.target.value);setPurchaseForm({...purchaseForm,productId:e.target.value,buy:p?String(p.buy):''})}}><option value="">পণ্য বেছে নিন</option>{products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select><input className="field" type="number" placeholder="কত পরিমাণ কিনেছেন" value={purchaseForm.qty} onChange={e=>setPurchaseForm({...purchaseForm,qty:e.target.value})}/><input className="field" type="number" placeholder="প্রতি পণ্যের পাইকারি দাম" value={purchaseForm.buy} onChange={e=>setPurchaseForm({...purchaseForm,buy:e.target.value})}/><input className="field" placeholder="বিক্রেতা / সরবরাহকারীর নাম" value={purchaseForm.supplier} onChange={e=>setPurchaseForm({...purchaseForm,supplier:e.target.value})}/><button className="w-full bg-emerald-600 text-white rounded-xl py-3 font-bold">ক্রয় সংরক্ষণ করুন</button></form><div className="font-bold mt-5 mb-2">ক্রয়ের ইতিহাস</div>{(data.purchases||[]).map(x=><Card key={x.id} className="p-3 mb-2"><div className="flex justify-between"><div><b>{x.product}</b><div className="text-xs text-slate-400">{x.date} · {x.qty} পিস/একক · {x.supplier}</div></div><b>{money(x.total)}</b></div></Card>)}</div></>}

      {page === 'due' && <><Header title="বাকি খাতা" sub="যাদের কাছে টাকা পাওনা আছে"/><div className="p-4"><Stat label="মোট পাওনা" value={money(totalDue)} color="text-rose-600"/><div className="font-bold mt-5 mb-3">ক্রেতাভিত্তিক বাকি</div>{dues.length?dues.map(d=><Card key={d.key} className="p-4 mb-3"><div className="flex justify-between"><div><div className="font-bold">{d.name}</div><div className="text-xs text-slate-400">{d.phone||'মোবাইল নেই'}</div><div className="text-xs text-slate-400">{d.address}</div></div><div className="text-right"><div className="font-extrabold text-rose-600">{money(d.due)}</div><button onClick={()=>addPayment(d)} className="mt-2 bg-emerald-600 text-white rounded-lg px-3 py-2 text-xs">＋ টাকা জমা</button></div></div></Card>):<Card className="p-5 text-center text-slate-400">কোনো বাকি নেই 🎉</Card>}<div className="font-bold mt-5 mb-2">জমার ইতিহাস</div>{(data.payments||[]).map(p=><Card key={p.id} className="p-3 mb-2 flex justify-between"><div><b>{p.customerName}</b><div className="text-xs text-slate-400">{p.date}</div></div><b className="text-emerald-700">+{money(p.amount)}</b></Card>)}</div></>}

      {page === 'sales' && <><Header title="বিক্রির ইতিহাস" sub="প্রতিটি বিক্রির বিস্তারিত হিসাব"/><div className="p-4"><input type="date" value={dateFilter} onChange={e=>setDateFilter(e.target.value)} className="field"/><div className="space-y-2 mt-3">{sales.filter(s=>s.date===dateFilter).map(s=><Card key={s.id} className="p-4"><div className="flex justify-between"><div><b>{s.customerName}</b><div className="text-xs text-slate-400">{s.date} · {s.customerPhone}</div></div><b>{money(s.total)}</b></div><div className="text-xs text-slate-500 mt-2">{s.items.map(i=>`${i.name} × ${i.qty}`).join(', ')}</div><div className="flex justify-between text-xs mt-3"><span className="text-emerald-700">লাভ: {money(s.profit)}</span><span className="text-rose-600">বাকি: {money(s.due)}</span></div></Card>)}{!sales.some(s=>s.date===dateFilter)&&<Card className="p-5 text-center text-slate-400">এই তারিখে বিক্রি নেই</Card>}</div></div></>}

      {page === 'expenses' && <><Header title="দোকানের খরচ" sub="দৈনিক অন্যান্য খরচ লিখে রাখুন"/><div className="p-4"><form onSubmit={saveExpense} className="bg-white p-4 rounded-2xl space-y-2"><input className="field" placeholder="খরচের নাম (যেমন: ভাড়া, বিদ্যুৎ)" value={expenseForm.title} onChange={e=>setExpenseForm({...expenseForm,title:e.target.value})}/><input className="field" type="number" placeholder="টাকার পরিমাণ" value={expenseForm.amount} onChange={e=>setExpenseForm({...expenseForm,amount:e.target.value})}/><input className="field" placeholder="বিস্তারিত (ঐচ্ছিক)" value={expenseForm.note} onChange={e=>setExpenseForm({...expenseForm,note:e.target.value})}/><button className="w-full bg-emerald-600 text-white rounded-xl py-3">খরচ সংরক্ষণ</button></form><div className="font-bold mt-5 mb-2">খরচের তালিকা</div>{(data.expenses||[]).map(e=><Card key={e.id} className="p-3 mb-2 flex justify-between"><div><b>{e.title}</b><div className="text-xs text-slate-400">{e.date} · {e.note}</div></div><b className="text-rose-600">{money(e.amount)}</b></Card>)}</div></>}

      {page === 'reports' && <><Header title="ব্যবসায়িক রিপোর্ট" sub="বিক্রি, লাভ, ক্রয় ও খরচের সারাংশ"/><div className="p-4 grid grid-cols-2 gap-3"><Stat label="মোট বিক্রি" value={money(sales.reduce((a,s)=>a+s.total,0))}/><Stat label="বিক্রির লাভ" value={money(sales.reduce((a,s)=>a+s.profit,0))} color="text-emerald-700"/><Stat label="মোট ক্রয়" value={money((data.purchases||[]).reduce((a,p)=>a+p.total,0))}/><Stat label="মোট খরচ" value={money((data.expenses||[]).reduce((a,e)=>a+e.amount,0))} color="text-rose-600"/><div className="col-span-2"><Stat label="খরচ বাদে আনুমানিক লাভ" value={money(allProfit)} color="text-violet-700"/></div><div className="col-span-2"><Stat label="এখনো পাওনা" value={money(totalDue)} color="text-rose-600"/></div></div><div className="px-4"><Card className="p-4 text-sm text-slate-500">লাভ = বিক্রয়মূল্য − পণ্যের ক্রয়মূল্য। দোকানের অন্যান্য খরচ বাদ দিয়ে নিট লাভ দেখানো হয়েছে।</Card></div></>}

      {page === 'more' && <><Header title="অন্যান্য" sub="দোকানের সব হিসাব এক জায়গায়"/><div className="p-4 space-y-2">{[['products','🛍 পণ্য ও স্টক'],['sales','🧾 বিক্রির ইতিহাস'],['reports','📊 ব্যবসায়িক রিপোর্ট'],['expenses','💸 দোকানের খরচ'],['purchase','📦 মাল ক্রয়']].map(([id,label])=><button key={id} onClick={()=>setPage(id)} className="w-full text-left bg-white p-4 rounded-xl border font-semibold">{label} <span className="float-right text-slate-400">›</span></button>)}<button onClick={()=>{const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`my-shop-backup-${today()}.json`;a.click();URL.revokeObjectURL(url);}} className="w-full text-left bg-white p-4 rounded-xl border font-semibold">⬇️ হিসাবের ব্যাকআপ ডাউনলোড</button><button onClick={()=>{if(confirm('সব হিসাব মুছে যাবে। আগে ব্যাকআপ নিয়েছেন তো?')){localStorage.removeItem('my-shop-pos-v1');setData(initial);setCart([]);notify('ডেটা রিসেট হয়েছে')}}} className="w-full text-left bg-rose-50 text-rose-600 p-4 rounded-xl border border-rose-100 font-semibold">সব ডেটা রিসেট</button><p className="text-xs text-slate-400 leading-5">নোট: এই প্রাথমিক সংস্করণে তথ্য এই ব্রাউজার/ফোনে সংরক্ষিত থাকে। অ্যাপের ডেটা মুছে গেলে বা অন্য ফোনে গেলে ব্যাকআপ ছাড়া তথ্য নাও পাওয়া যেতে পারে।</p></div></>}

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-100 grid grid-cols-5 px-1 py-2 z-20">{nav.map(n=><button key={n.id} onClick={()=>{setPage(n.id);setQuery('')}} className={`flex flex-col items-center gap-1 py-1 text-[11px] ${page===n.id?'text-emerald-700 font-bold':'text-slate-400'}`}><span className={`text-xl ${page===n.id?'bg-emerald-100 rounded-xl px-3 py-1':''}`}>{n.icon}</span>{n.label}</button>)}</div>
      {notice && <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-sm px-4 py-3 rounded-xl shadow-lg z-50 whitespace-nowrap">{notice}</div>}
      <style>{`.field{width:100%;border:1px solid #e2e8f0;border-radius:12px;padding:11px 12px;background:white;outline:none;font-size:14px}.field:focus{border-color:#059669;box-shadow:0 0 0 2px #d1fae5}`}</style>
    </div>
  </div>;
}

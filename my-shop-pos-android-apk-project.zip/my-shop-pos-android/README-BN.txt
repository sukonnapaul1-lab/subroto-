MY SHOP POS — ANDROID APK BUILD (শুধু Android ফোন দিয়ে)

এই ZIP-এ তোমার App.jsx-সহ সম্পূর্ণ React + Vite + Capacitor প্রজেক্ট আছে। GitHub Actions-এর ক্লাউড কম্পিউটার দিয়ে APK বানানোর জন্য নিচের সহজ পদ্ধতি অনুসরণ করো। Android Studio বা কম্পিউটার লাগবে না।

যা লাগবে: GitHub অ্যাকাউন্ট এবং ইন্টারনেট।

ধাপ ১ — ZIP আপলোড
১) এই ZIP Extract করবে না; আসল ZIP ফাইলটাই রাখবে।
২) Chrome-এ https://github.com খোলো এবং নিজের অ্যাকাউন্টে Sign in করো।
৩) New repository তৈরি করো। নাম দাও my-shop-pos-apk।
৪) Repository খোলার পর Add file > Upload files চাপো।
৫) এই ZIP ফাইলটি আপলোড করে Commit changes চাপো।

ধাপ ২ — Build workflow তৈরি
১) Repository-তে Add file > Create new file চাপো।
২) ফাইলের নামের ঘরে হুবহু লেখো:
   .github/workflows/build-apk.yml
৩) এই ZIP-এর ভেতরের GITHUB-WORKFLOW-COPY.txt ফাইলটি খোলো, তার সব লেখা Copy করে GitHub-এর নতুন ফাইলে Paste করো।
৪) Commit changes চাপো।

ধাপ ৩ — APK তৈরি
১) Repository-র Actions ট্যাব খোলো।
২) বাম পাশে Build My Shop POS APK নির্বাচন করো।
৩) Run workflow > Run workflow চাপো। প্রথমবার Commit করার পরও workflow নিজে থেকে শুরু হতে পারে।
৪) কিছুক্ষণ অপেক্ষা করো। কাজ শেষ হলে সবুজ টিক চিহ্ন দেখাবে।

ধাপ ৪ — ফোনে ইনস্টল
১) সফল workflow run খুলে নিচে Artifacts অংশ খুঁজে বের করো।
২) My-Shop-POS-APK ডাউনলোড করো। এটি ZIP ফাইল হবে।
৩) ZIP Extract করো। ভেতরে app-debug.apk পাবে।
৪) app-debug.apk চাপো এবং Android-এর Install নির্দেশনা অনুসরণ করো। সতর্কতা এলে ফাইলটি তোমার নিজের তৈরি করা বিল্ড কিনা নিশ্চিত হয়ে তবেই ইনস্টল করবে।

গুরুত্বপূর্ণ:
- এখনো APK ফাইল তৈরি করা হয়নি; এই প্রজেক্ট ZIP হলো APK তৈরির উপকরণ। GitHub Actions সফলভাবে চললে APK পাওয়া যাবে।
- এটি Debug APK, নিজের ফোনে পরীক্ষা ও ব্যবহারের জন্য; Play Store-এ প্রকাশের জন্য আলাদা signed release build দরকার।
- এই অ্যাপের বর্তমান কোড localStorage ব্যবহার করে। তথ্য অ্যাপের নিজস্ব ফোন-স্টোরেজে থাকবে। অ্যাপের ডেটা Clear বা Uninstall করলে তথ্য হারাতে পারো। অ্যাপের ভিতরের Backup Download নিয়মিত ব্যবহার করো।
- Firebase বা Cloud Sync এখনো যুক্ত নেই; অন্য ফোনে তথ্য নিজে থেকে যাবে না।
- GitHub-এর স্ক্রিনে কোনো ধাপ খুঁজে না পেলে সেই স্ক্রিনের ছবি পাঠাও; আমি পরের ধাপ দেখিয়ে দেব।
